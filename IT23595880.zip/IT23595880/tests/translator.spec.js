const { test, expect } = require('@playwright/test');

test.beforeEach(async ({ page }) => {
  await page.goto('https://www.swifttranslator.com/');
});


// =======================
// POSITIVE FUNCTIONAL TEST CASES (24)
// =======================

test('Pos_Fun_0001 - Single Singlish word', async ({ page }) => {
  await page.locator('textarea').fill('Amma');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0002 - Simple sentence', async ({ page }) => {
  await page.locator('textarea').fill('mama gedhara yanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0003 - Question sentence', async ({ page }) => {
  await page.locator('textarea').fill('oyata kohomada');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0004 - Interrogative sentence', async ({ page }) => {
  await page.locator('textarea').fill('oya enne kavadhdha');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0005 - Sentence with numbers', async ({ page }) => {
  await page.locator('textarea').fill('mata thawa 2k oonee');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0006 - Sentence with punctuation', async ({ page }) => {
  await page.locator('textarea').fill('hi, oyata kohomada');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0007 - Polite request', async ({ page }) => {
  await page.locator('textarea').fill('karunaakaralaa mata udhavvak karanna puluvandha');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0008 - Past tense sentence', async ({ page }) => {
  await page.locator('textarea').fill('mama iiyee oyata call kala');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0009 - Mixed case input', async ({ page }) => {
  await page.locator('textarea').fill('MaMa GeDhArA YaNaVaA');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0010 - Informal sentence', async ({ page }) => {
  await page.locator('textarea').fill('api honda widihata hithamu');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0011 - Sentence with name', async ({ page }) => {
  await page.locator('textarea').fill('Luhith gedhara giyaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0012 - Command sentence', async ({ page }) => {
  await page.locator('textarea').fill('dora lock karanna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0013 - Emotional sentence', async ({ page }) => {
  await page.locator('textarea').fill('ayyo mata mokada une');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0014 - Sentence with location', async ({ page }) => {
  await page.locator('textarea').fill('mama dn kadawatha inne');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0015 - Food related sentence', async ({ page }) => {
  await page.locator('textarea').fill('hawasa api kottuwak kawa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0016 - Mixed Singlish + English', async ({ page }) => {
  await page.locator('textarea').fill('mata Zoom meeting ekak thiyenavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=Zoom')).toBeVisible();
});

test('Pos_Fun_0017 - English place name', async ({ page }) => {
  await page.locator('textarea').fill('api Colombo yamu');
  await page.waitForTimeout(800);
  await expect(page.locator('text=Colombo')).toBeVisible();
});

test('Pos_Fun_0018 - Currency format', async ({ page }) => {
  await page.locator('textarea').fill('Rs. 5000 genna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=5000')).toBeVisible();
});

test('Pos_Fun_0019 - Time format', async ({ page }) => {
  await page.locator('textarea').fill('7.30 AM enna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=7.30')).toBeVisible();
});

test('Pos_Fun_0020 - Date format', async ({ page }) => {
  await page.locator('textarea').fill('2025-12-25 enavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=2025')).toBeVisible();
});

test('Pos_Fun_0021 - Units of measurement', async ({ page }) => {
  await page.locator('textarea').fill('kg 5k ganan karanna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=kg')).toBeVisible();
});

test('Pos_Fun_0022 - Multiple spaces', async ({ page }) => {
  await page.locator('textarea').fill('mama   gedhara   yanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0023 - Line break input', async ({ page }) => {
  await page.locator('textarea').fill('mama gedhara yanavaa\no yaa enavadha');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Pos_Fun_0024 - Paragraph input', async ({ page }) => {
  await page.locator('textarea').fill('mama gedhara innee. api heta yamu. oyaa enna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});


// =======================
// NEGATIVE FUNCTIONAL TEST CASES (10)
// =======================

test('Neg_Fun_0001 - Joined words', async ({ page }) => {
  await page.locator('textarea').fill('mamagedharayanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0002 - Typo input', async ({ page }) => {
  await page.locator('textarea').fill('mata bat oone');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0003 - Slang input', async ({ page }) => {
  await page.locator('textarea').fill('ela machan supiri');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0004 - Mixed English typo', async ({ page }) => {
  await page.locator('textarea').fill('meetingk Zoom lnk evnna');
  await page.waitForTimeout(800);
  await expect(page.locator('text=Zoom')).toBeVisible();
});

test('Neg_Fun_0005 - Missing spaces', async ({ page }) => {
  await page.locator('textarea').fill('hetaapiyanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0006 - Repeated characters', async ({ page }) => {
  await page.locator('textarea').fill('mamaaaaa gedharaaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0007 - Extra symbols', async ({ page }) => {
  await page.locator('textarea').fill('mama gedhara yanavaa!!!');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});

test('Neg_Fun_0008 - Random English input', async ({ page }) => {
  await page.locator('textarea').fill('This is a random test input');
  await page.waitForTimeout(800);
  await expect(page.locator('text=This')).toBeVisible();
});

test('Neg_Fun_0009 - Numeric only input', async ({ page }) => {
  await page.locator('textarea').fill('1234567890');
  await page.waitForTimeout(800);
  await expect(page.locator('text=1')).toBeVisible();
});

test('Neg_Fun_0010 - Clear and re-enter', async ({ page }) => {
  const input = page.locator('textarea');
  await input.fill('');
  await input.fill('mama gedhara yanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});


// =======================
// UI TEST CASE (1)
// =======================

test('Pos_UI_0001 - Real time output update', async ({ page }) => {
  await page.locator('textarea').type('man gedhara yanavaa');
  await page.waitForTimeout(800);
  await expect(page.locator('text=ම')).toBeVisible();
});
